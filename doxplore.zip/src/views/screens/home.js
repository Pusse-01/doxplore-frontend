import React from 'react'
import PersistentDrawerLeft from '../../sidebar';
import Box from '@mui/material/Box';
import './styles.css'
import HomePage from '../components/home';

export default function home() {
  return (
<Box sx={{display:"flex"}}>
    <PersistentDrawerLeft/>
    <HomePage/>
</Box>


  )
}
